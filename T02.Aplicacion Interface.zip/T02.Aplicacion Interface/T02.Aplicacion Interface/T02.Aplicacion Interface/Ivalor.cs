﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace T02.Aplicacion_Interface
{
    interface Ivalor
    {//encapsulacion
         double ValorA { get; set; }
         double ValorB { get; set; }
    }
}
