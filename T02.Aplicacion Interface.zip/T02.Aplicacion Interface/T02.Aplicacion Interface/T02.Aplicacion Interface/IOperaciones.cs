﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace T02.Aplicacion_Interface
{
    interface IOperaciones
    {//clase de la interfas y sus metodos
        double SumaRes();
        double RestaRes();
        double DivicionRes();
        double MultiplicacionRes();
    }
}
