﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace T02.Aplicacion_Interface
{
    public class Principal
    {   //mensaje de la interfas con el metodo numeros
        public  virtual string Numeros()
        {
            return "Calculadora";
        }

    }
}
